<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Mathematics</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">
        <?php require_once 'include/header_include.php'; ?>
    </head>
    <body>
        <?php require_once 'include/header.php'; ?>
        <!--==========================
          Hero Section
        ============================-->
        <section id="hero" class="wow fadeIn">
            <div class="hero-container">
                <br/> <br/><br/><br/>
                <h1>Georgia Standards of Excellence Curriculum Map</h1>
                <h2>GSE 8th Grade-Mathematics </h2>
                <!--/<img src="img/hero-img.png" alt="Hero Imgs">-->
                <img src="img/logomain.jpg" alt="Hero Imgs">
                <a href="#pricing" class="btn-get-started scrollto">Get Started</a>
            </div>
        </section>

        <section id="pricing" class="padd-section text-center wow fadeInUp">
            <div class="container">
                <div class="section-title text-center">
                    <h2><a href="https://pathways.badgr.io/public/pathway/5b840be11d662d3b49705fc1/element/5b840be11d662d3b49705fc0" target="_blank">GSE Eighth Grade Curriculum Map</a> </h2>
                    <p class="separator">1st  Semester</p>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4><a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/01_TransConSim/index.html"  target="_blank">Unit 1</a></h4>
                                <h2>Transformations, Congruence and Similarity</h2>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li><a href="https://gavs.thrivistlms.com/tk12/courses/300/files/13575?module_item_id=632" target="_blank">Professional Development</a></li>
                                    <li>(4 – 5 Weeks)</li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d26090-9d60-11e7-8d5b-40212359c308" target="_blank">MGSE8.G.1</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d27a76-9d60-11e7-99a6-3587251ad724" target="_blank">MGSE8.G.2</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d29240-9d60-11e7-afd0-11ce649f735e" target="_blank">MGSE8.G.3</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d2a9c4-9d60-11e7-8064-92d49a083745" target="_blank">MGSE8.G.4</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d2c10c-9d60-11e7-9285-37eec92a2b6a" target="_blank">MGSE8.G.5</a></li>
                                </ul>
                                <div class="table_btn">
                                    <a href="https://customer.safarimontage.com/?p=63ef5ea1-a0c5-11e8-ae89-0cc47a765dd6" target="_blank" class="btn"><i class="fa fa-shopping-cart"></i> Resources</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4><a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/02_Exponents/index.html"  target="_blank">Unit 2</a></h4>
                                <h2>Exponents</h2>
                                <br/><br/><br/>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li>(4 – 5 weeks)</li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5cf68fe-9d60-11e7-ae6f-c77f4076fb65" target="_blank">MGSE8.EE1</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5cf828a-9d60-11e7-9568-b427bfb3023a" target="_blank">MGSE8.EE.2-evaluating</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5cf9b30-9d60-11e7-a56c-98711938e5e9" target="_blank">MGSE8.EE.3</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5cfb340-9d60-11e7-bec2-075cf08ffe0d" target="_blank">MGSE8.EE.4</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d00fc0-9d60-11e7-ac04-9e9cce96948d" target="_blank">MGSE8.EE.7</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d03cde-9d60-11e7-9a2e-f31d3d648e57" target="_blank">MGSE8.EE.7a</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d056f6-9d60-11e7-a05d-4e3398ca7bcb" target="_blank">MGSE8.EE.7b</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5ceccb4-9d60-11e7-bf5f-bd31286e65e7" target="_blank">MGSE8.NS.1</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5cee5aa-9d60-11e7-ba5c-b2c458a8e104" target="_blank">MGSE8.NS.2</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4><a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/03_GeoAppsExponents/index.html"  target="_blank">Unit 3</a></h4>
                                <h2>Geometric Applications of Exponents</h2>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li>(4 – 5 weeks)</li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d309b4-9d60-11e7-8f99-167fb50d6fb3" target="_blank">MGSE8.G.6</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d32368-9d60-11e7-99e8-8e8955aa93ca" target="_blank">MGSE8.G.7</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d33bbe-9d60-11e7-bf57-c65a7e5c6a63" target="_blank">MGSE8.G.8</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d37822-9d60-11e7-bfd1-50e9b1110df1" target="_blank">MGSE8.G.9</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5cf828a-9d60-11e7-9568-b427bfb3023a" target="_blank">MGSE8.EE.2-(equations)</a></li>
                                </ul>    
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4><a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/04_Functions/index.html"  target="_blank">Unit 4</a></h4>
                                <h2>Functions</h2>
                                    <br/><br/><br/>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li>(2 – 3 weeks)</li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d14a2a-9d60-11e7-bf82-1d7216954ab9" target="_blank">MGSE8.F.1</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d163e8-9d60-11e7-b21f-c04ac9313980" target="_blank">MGSE8.F.2</a></li>

                                </ul>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="pricing" class="padd-section text-center wow fadeInUp">
            <div class="container">
                <div class="section-title text-center">

                    <h3><a href="https://app.powerbi.com/view?r=eyJrIjoiMTFhNGZjNzEtNjRhNC00MzYyLTkzZDctYzk5ZjExNDZkYzZmIiwidCI6ImQ1OGJkNWJiLWYzN2YtNGFkMS1iZjhmLTYyZmM1ZTlmN2JlYSIsImMiOjF9" target="_blank">Map Results Dashboard </a></h3>
                    <h2> <h2>GSE Eighth Grade Curriculum Map </h2></h2>
                    <p class="separator">2nd  Semester</p>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4><a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/05_LinearFunctions/index.html"  target="_blank">Unit 5</a></h4>
                                <h2>Linear Functions</h2>
                                <br/><br/>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li>(3 – 4 weeks)</li>
                                    <li><a href="https://case.georgiastandards.org/uri/bfdc5aec-a9de-11e7-9f3c-4fd6881b5476" target="_blank">MGSE8.EE.5</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/d9008638-a9de-11e7-800a-988e1fc78e6a" target="_blank">MGSE8.EE.6</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d17bb2-9d60-11e7-85c5-d6a04cf2177b" target="_blank">MGSE8.F.3</a></li>
                                </ul> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4><a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/06_LinearModelsTables/index.html"  target="_blank">Unit 6</a></h4>
                                <h2>Linear Models and Tables</h2>
                                <br/><br/>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li>(5 – 6 weeks)</li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d1bed8-9d60-11e7-bd27-121e955ec91c" target="_blank">MGSE8.F.4</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d1d7f6-9d60-11e7-91b6-8bc4e0067f14" target="_blank">MGSE8.F.5</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/44a27bca-a9e0-11e7-a3ba-3d887d89ec76" target="_blank">MGSE8.SP.1</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/611797a4-a9e0-11e7-a46c-8a89f9906ccc" target="_blank">MGSE8.SP.2</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d3e1b8-9d60-11e7-aef0-e61a16ec5fc9" target="_blank">MGSE8.SP.3</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d3fbda-9d60-11e7-b53d-e5f1b7c33bcd" target="_blank">MGSE8.SP.4</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4><a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/07_SystemsofEquations/index.html"  target="_blank">Unit 7</a></h4>
                                <h3>Solving Systems of Equations</h3>
                                <br/><br/><br/><br/>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li>(4 – 5 weeks)</li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d06f74-9d60-11e7-adac-a8b8e5a19ddd" target="_blank">MGSE8.EE.8</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d0a192-9d60-11e7-a07c-d7a63e4d8636" target="_blank">MGSE8.EE.8a</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d0bb0a-9d60-11e7-a342-d57bb6f7b30a" target="_blank">MGSE8.EE.8b</a></li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5d0d37e-9d60-11e7-b9d1-f9bb48dc3fb2" target="_blank">MGSE8.EE.8c</a></li>
                                </ul>    
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4><a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/08_ShowWhatWeKnow/index.html"  target="_blank">Unit 8</a></h4>
                                <h2>Show What We Know</h2>
                                <br/><br/>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li>(3 – 4 weeks)</li>
                                    <li><a href="https://case.georgiastandards.org/uri/f5ce361e-9d60-11e7-b488-e4650695f4ea" target="_blank">ALL</a></li>
                                    <li>Plus High School Prep Review</li>
                                </ul>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- #hero -->
        <!--==========================
          Get Started Section
        ============================-->

        <section id="get-started" class="padd-section text-center wow fadeInUp">
            <div class="container">
                <div class="section-title text-center">
                    <h2>Georgia Standards of Excellence Eighth Grade Mathematics Curriculum Map Rationale</h2>
                    <p class="separator">Georgia Department of Education</p>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-4">
                        <div class="feature-block justify-content ">
                            <img src="img/lo.png" alt="img" class="img-fluid">
                            <a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/01_TransConSim/index.html" target="_blank"><h3>Unit 1</h3></a> 
                            <p>This unit centers around geometry standards related to transformations both on and off the coordinate plane – translations, reflections, rotations, and dilations. Students develop understanding of congruence and similarity using physical models, transparencies, or geometry software, and learn to use informal arguments to establish proof of angle sum and exterior angle relationships</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="feature-block justify-content">
                            <img src="img/lo.png" alt="img" class="img-fluid">
                            <a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/02_Exponents/index.html" target="_blank"><h3>Unit 2</h3></a> 
                            <p>Students explore and understand numbers that are not rational (irrational numbers) and approximate their value by using rational numbers. Students work with radicals and express very large and very small numbers using integer exponents</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="feature-block justify-content">
                            <img src="img/lo.png" alt="img" class="img-fluid">
                            <a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/03_GeoAppsExponents/index.html" target="_blank"><h3>Unit 3</h3></a> 
                            <p>Students extend their work with irrational numbers by applying the Pythagorean Theorem to situations involving right triangles, including finding distance, and will investigate proofs of the Pythagorean Theorem and its converse. Students solve real-world problems involving volume of cylinders, cones, and spheres</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-lg-4">
                        <div class="feature-block justify-content">
                            <img src="img/lo.png" alt="img" class="img-fluid">
                            <a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/04_Functions/index.html" target="_blank"><h3>Unit 4</h3></a> 
                            <p>Students are introduced to relations and functions. Students define, evaluate, and compare functions. Functions are described and modeled using a variety of depictions, including algebraic representation, graphic representation, numerical tables, and verbal descriptions</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="feature-block justify-content">
                            <img src="img/lo.png" alt="img" class="img-fluid">
                            <a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/05_LinearFunctions/index.html" target="_blank"><h3>Unit 5</h3></a> 

                            <p>Students further explore functions, focusing on the study of linear functions. Students develop understanding of the connections between proportional relationships, lines, and linear equations, and solve mathematical and real-life problems involving such relationships. Slope is formally introduced, and students work with equations for slope in different forms, including comparing proportional relationships depicted in different ways (graphical, tabular, algebraic, verbal).</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="feature-block justify-content">
                            <img src="img/lo.png" alt="img" class="img-fluid">
                            <a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/06_LinearModelsTables/index.html" target="_blank"><h3>Unit 6</h3></a> 
                            <p>Students extend the study of linear relationships by exploring models and tables to describe rate of change. The study of statistics expands to bivariate data, which can be graphed and a line of best fit determined</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="feature-block justify-content">
                            <img src="img/lo.png" alt="img" class="img-fluid">
                            <a href="http://cms.gavirtualschool.org/Shared/Math/MSMath8_13/07_SystemsofEquations/index.html" target="_blank"><h3>Unit 7</h3></a> 
                            <p>The final unit broadens the study of linear equations to include situations involving simultaneous equations. Using graphing, substitution, and elimination, students learn to solve systems of equations algebraically, and make applications to real-world situations.   </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--==========================
          About Us Section
        ============================-->
        <section id="about-us" class="about-us padd-section wow fadeInUp">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-5 col-lg-3">
                        <img src="img/hero-img.png" alt="About">
                    </div>
                    <div class="col-md-7 col-lg-5">
                        <h2><span>More Links </span></h2>
                        <h3>Georgia Department of Education</h3>
                        <br/>
                        <ul class="list-unstyled">
                            <li><i class="fa fa-angle-right"></i><a href="https://case.georgiastandards.org/uri/7272a334-46fa-11e7-8be9-f378a76d884e" target="_blank">6th Grade Mathematics Standards</a></li>
                            <li><i class="fa fa-angle-right"></i><a href="https://case.georgiastandards.org/uri/ef147630-9d60-11e7-b311-10950f516b35" target="_blank">7th Grade Mathematics Standards</a></li>
                            <li><i class="fa fa-angle-right"></i><a href="https://case.georgiastandards.org/uri/f5ce361e-9d60-11e7-b488-e4650695f4ea" target="_blank">8th Grade Mathematics Standards</a></li>
                            <li><i class="fa fa-angle-right"></i><a href="http://www.gadoe.org/Curriculum-Instruction-and-Assessment/Assessment/Pages/Georgia-Milestones-Test-Blueprints.aspx" target="_blank">Georgia Milestones Blueprint – 8th Grade</a></li>
                            <li><i class="fa fa-angle-right"></i><a href="http://www.gavirtuallearning.org/Resources/SharedMSMath6.aspx" target="_blank">Georgia Virtual School Shared Content – Middle School, 6th Grade Math</a></li>
                            <li><i class="fa fa-angle-right"></i><a href="http://www.gavirtuallearning.org/Resources/SharedMS7thMath.aspx" target="_blank">Georgia Virtual School Shared Content – Middle School, 7th Grade Math</a></li>
                            <li><i class="fa fa-angle-right"></i><a href="http://www.gavirtuallearning.org/Resources/SharedMSMath8th.aspx" target="_blank">Georgia Virtual School Shared Content – Middle School, 8th Grade Math</a></li>
                            <li><i class="fa fa-angle-right"></i><a href="http://www.gadoe.org/support" target="_blank">GADOE Contacts and Support</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section id="pricing" class="padd-section text-center wow fadeInUp">
            <div class="container">
                <div class="section-title text-center">
                    <h2>GSE Eighth Grade Expanded Curriculum Map</h2>
                    <h2>1st Semester</h2>
                    <p class="separator">Standards for Mathematical Practice</p>    
                </div>
                <div class="row">  
                    <div class="col-md-2 col-lg-6">
                        <div class="block-pricing">
                            <div class="table">
                                <ul class="list-group-item-dark">
                                    <li>1 Make sense of problems and persevere in solving them.</li>
                                    <li>2 Reason abstractly and quantitatively.</li>
                                    <li>3 Construct viable arguments and critique the reasoning of others.</li>
                                    <li>4 Model with mathematics.</li>
                                </ul> 
                            </div>
                        </div> 
                    </div>
                    <div class="col-md-2 col-lg-6"><div class="block-pricing">
                            <div class="table">
                                <ul class="list-group-item-dark">
                                    <li>5 Use appropriate tools strategically.</li>
                                    <li>6 Attend to precision.</li>
                                    <li>7 Look for and make use of structure.</li>
                                    <li>8 Look for and express regularity in repeated reasoning.</li>   
                                </ul> 
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4>Unit 1</h4>
                                <h3>Transformations, Congruence and Similarity</h3>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li>Understand congruence and similarity using physical models, transparencies, or geometry software</li>
                                    <li></li>
                                    <li><b>MGSE8.G.1</b> Verify experimentally the congruence properties of rotations, reflections, and translations:  lines are taken to lines and line segments to line segments of the same length; angles are taken to angles of the same measure; parallel lines are taken to parallel lines. </li>
                                    <li><b>MGSE8.G.2</b> Understand that a two- dimensional figure is congruent to another if the second can be obtained from the first by a sequence of rotations, reflections, and translations; given two congruent figures, describe a sequence that exhibits the congruence between them.</li>
                                    <li><b>MGSE8.G.3</b> Describe the effect of dilations, translations, rotations and reflections on two- dimensional figures using coordinates. </li>
                                    <li><b>MGSE8.G.4</b> Understand that a two- dimensional figure is similar to another if the second can be obtained from the first by a sequence of rotations, reflections, translations, and dilations; given two similar two- dimensional figures, describe a sequence that exhibits the similarity between them. </li>
                                    <li><b>MGSE8.G.5</b> Use informal arguments to establish facts about the angle sum and exterior angle of triangles, about the angles created when parallel lines are cut by a transversal, and the angle-angle criterion for similarity of triangles.</li>
                                </ul>   
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4>Unit 2</h4>
                                <h3>Exponents</h3>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li><b>Work with radicals and integer exponents</b></li>
                                    <li></li>
                                    <li><b>MGSE8.EE.1</b> Know and apply the properties of integer exponents to generate equivalent numerical expressions.</li>
                                    <li><b>MGSE8.EE.2</b> Use square root and cube root symbols to represent solutions to equations. Recognize that x² = p (where p is a positive rational number and lxl < 25) has 2 solutions and x³ = p (where p is a negative or positive rational number and lxl < 10) has one solution. Evaluate square roots of perfect squares < 625 and cube roots of perfect cubes > -1000 and < 1000.</li>
                                    <li><b>MGSE8.EE.3</b> Use numbers expressed in scientific notation to estimate very large or very small quantities, and to express how many times as much one is than the other.  For example, estimate the population of the United States as 3 × 108 and the population of the world as 7 × 109, and determine that the world population is more than 20 times larger.</li>
                                    <li><b>MGSE8.EE.4</b> Add, subtract, multiply and divide numbers expressed in scientific notation, including problems where both decimal and scientific notation are used. Understand scientific notation and choose units of appropriate size for measurements of very large or very small quantities (e.g. use millimeters per year for seafloor spreading). Interpret scientific notation that has been generated by technology (e.g. calculators).</li>
                                    <li></li>
                                    <li><b>Analyze and solve linear equations and pairs of simultaneous linear equations.</b></li>
                                    <li></li>
                                    <li><b>MGSE8.EE.7</b> Solve linear equations in one variable.</li>
                                    <li><b>MGSE8.EE.7a</b> Give examples of linear equations in one variable with one solution, infinitely many solutions, or no solutions. Show which of these possibilities is the case by successively transforming the given equation into simpler forms, until an equivalent equation of the form x = a, a = a, or a = b results (where a and b are different numbers).</li>
                                    <li><b>MGSE8.EE.7b</b> Solve linear equations with rational number coefficients, including equations whose solutions require expanding expressions using the distributive property and collecting like terms. </li>
                                    <li></li>
                                    <li><b>Know that there are numbers that are not rational, and approximate them by rational numbers.</b></li>
                                    <li></li>
                                    <li><b>MGSE8.NS.1</b> Know that numbers that are not rational are called irrational. Understand informally that every number has a decimal expansion; for rational numbers show that the decimal expansion repeats eventually, and convert a decimal expansion which repeats eventually into a rational number. </li>
                                    <li><b>MGSE8.NS.2</b> Use rational approximation of irrational numbers to compare the size of irrational numbers, locate them approximately on a number line, and estimate the value of expressions (e.g., estimate π² to the nearest tenth). For example, by truncating the decimal expansion of √2 (square root of 2), show that √2 is between 1 and 2, then between 1.4 and 1.5, and explain how to continue on to get better approximations.</li>
                                </ul>   
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4>Unit 3</h4>
                                <h3>Geometric Applications of Exponents</h3>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li><b>Understand and apply the Pythagorean Theorem</b></li>
                                    <li><b>MGSE8.G.6</b> Explain a proof of thePythagorean Theorem and its converse.</li>
                                    <li><b>MGSE8.G.7</b> Apply the Pythagorean Theorem to determine unknown side lengths in right triangles in real-world and mathematical problems in two and three dimensions.</li>
                                    <li><b>MGSE8.G.8</b> Apply the Pythagorean Theorem to find the distance between two points in a coordinate system.</li>
                                    <li></li>
                                    <li><b>Solve real-world and mathematical problems involving volume of cylinders, cones, and spheres.</b></li>
                                    <li></li> 
                                    <li><b>MGSE8.G.9</b> Apply the formulas for the volume of cones, cylinders, and spheres and use them to solve real-world and mathematical problems.</li>
                                    <li></li>
                                    <li><b>Work with radicals and integer exponents</b></li>
                                    <li></li>
                                    <li><b>MGSE8.EE.2</b> Use square root and cube root symbols to represent solutions to equations. Recognize that x² = p (where p is a positive rational number and lxl < 25) has 2 solutions and x³ = p (where p is a negative or positive rational number and lxl < 10) has one solution. Evaluate square roots of perfect squares < 625 and cube roots of perfect cubes > -1000 and < 1000.</li>
                                </ul>   
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4>Unit 4</h4>
                                <h3>Functions</h3>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li><b>Define, evaluate, and compare functions</b></li>
                                    <li><b>MGSE8.F.1</b> Understand that a function is a rule that assigns to each input exactly one output. The graph of a function is the set of ordered pairs consisting of an input and the corresponding output.</li>
                                    <li><b>MGSE8.F.2</b> Compare properties of two functions each represented in a different way (algebraically, graphically, numerically in tables, or by verbal descriptions).</li>
                                    <li></li>
                                </ul>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="pricing" class="padd-section text-center wow fadeInUp">
            <div class="container">
                <div class="section-title text-center">
                    <h2>GSE Eighth Grade Expanded Curriculum Map</h2>       
                    <h2>2nd Semester</h2>
                    <p class="separator">Standards for Mathematical Practice</p>    
                </div>
                <div class="row">  
                    <div class="col-md-2 col-lg-6">
                        <div class="block-pricing">
                            <div class="table">
                                <ul class="list-group-item-dark">
                                    <li>1 Make sense of problems and persevere in solving them.</li>
                                    <li>2 Reason abstractly and quantitatively.</li>
                                    <li>3 Construct viable arguments and critique the reasoning of others.</li>
                                    <li>4 Model with mathematics.</li>
                                </ul> 
                            </div>
                        </div> 
                    </div>
                    <div class="col-md-2 col-lg-6"><div class="block-pricing">
                            <div class="table">
                                <ul class="list-group-item-dark">
                                    <li>5 Use appropriate tools strategically.</li>
                                    <li>6 Attend to precision.</li>
                                    <li>7 Look for and make use of structure.</li>
                                    <li>8 Look for and express regularity in repeated reasoning.</li>   
                                </ul> 
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4>Unit 5</h4>
                                <h3>Linear Functions</h3>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li><b>Understand the connections between proportional relationships, lines, and linear equations</b></li>
                                    <li><b>MGSE8.EE.5</b> Graph proportional relationships, interpreting the unit rate as the slope of the graph. Compare two different proportional relationships represented in different ways</li>
                                    <li><b>MGSE8.EE.6</b> Use similar triangles to explain why the slope m is the same between any two distinct points on a non‐vertical line in the coordinate plane; derive the equation y = mx for a line through the origin and the equation y = mx + b for a line intercepting the vertical axis at b.</li>
                                    <li></li>
                                    <li><b>Define, evaluate, and compare functions.</b></li>
                                    <li></li>
                                    <li><b>MGSE8.F.3</b> Interpret the equation y = mx + b as defining a linear function, whose graph is a straight line; give examples of functions that are not linear. For example, the function A = s2 giving the area of a square as a function of its side length is not linear because its graph contains the points (1,1), (2,4) and (3,9), which are not on a straight line</li>
                                    <li></li>
                                </ul>   
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4>Unit 6</h4>
                                <h3>Linear Models and Tables</h3>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li><b>Use functions to model relationships between quantities.</b></li>
                                    <li></li>
                                    <li><b>MGSE8.F.4</b> Construct a function to model a linear relationship between two quantities. Determine the rate of change and initial value of the function from a description of a relationship or from two (x,y) values, including reading these from a table or from a graph. Interpret the rate of change and initial value of a linear function in terms of the situation it models, and in terms of its graph or a table of values.</li>
                                    <li><b>MGSE8.F.5</b> Describe qualitatively the functional relationship between two quantities by analyzing a graph (e.g., where the function is increasing or decreasing, linear or nonlinear). Sketch a graph that exhibits the qualitative features of a function that has been described verbally.</li>
                                    <li></li>
                                    <li><b>Investigate patterns of association in bivariate data.</b></li>
                                    <li></li>
                                    <li><b>MGSE8.SP.1</b> Construct and interpret scatter plots for bivariate measurement data to investigate patterns of association between two quantities. Describe patterns such as clustering, outliers, positive or negative association, linear association, and nonlinear association.</li>
                                    <li><b>MGSE8.SP.2</b> Know that straight lines are widely used to model relationships between two quantitative variables. For scatter plots that suggest a linear association, informally fit a straight line, and informally assess the model fit by judging the closeness of the data points to the line.</li>
                                    <li><b>MGSE8.SP.3</b> Use the equation of a linear model to solve problems in the context of bivariate measurement data, interpreting the slope and intercept.</li>
                                    <li><b>MGSE8.SP.4</b> Understand that patterns of association can also be seen in bivariate categorical data by displaying frequencies and relative frequencies in a two-way table.</li>
                                    <li>a. Construct and interpret a two-way table summarizing data on two categorical variables collected from the same subjects.</li>
                                    <li>b. Use relative frequencies calculated for rows or columns to describe possible association between the two variables.  For example, collect data from students in your class on whether or not they have a curfew on school nights and whether or not they have assigned chores at home.  Is there evidence that those who have a curfew also tend to have chores?</li>
                                    <li></li>
                                </ul>   
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4>Unit 7</h4>
                                <h3>Solving Systems of Equations</h3>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li><b>Analyze and solve linear equations and pairs of simultaneous linear equations.</b></li>
                                    <li><b>MGSE8.EE.8</b> Analyze and solve pairs of simultaneous linear equations (systems of linear equations).</li>
                                    <li><b>MGSE8.EE.8a</b> Understand that solutions to a system of two linear equations in two variables correspond to points of intersection of their graphs, because points of intersection satisfy both equations simultaneously.</li>
                                    <li><b>MGSE8.EE.8b</b> Solve systems of two linear equations in two variables algebraically, and estimate solutions by graphing the equations. Solve simple cases by inspection.</li>
                                    <li><b>MGSE8.EE.8c</b> Solve real-world and mathematical problems leading to two linear equations in two variables.</li>
                                    <li></li>
                                </ul>   
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="block-pricing">
                            <div class="table">
                                <h4>Unit 8</h4>
                                <h3>Show What We Know</h3>
                                <ul class="list-unstyled">
                                    <li></li>
                                    <li><b>ALL</b></li>
                                    <li>Plus High School Prep Review</li>
                                    <li></li>
                                </ul>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php require_once 'include/footer.php'; ?>
    </body>
</html>
