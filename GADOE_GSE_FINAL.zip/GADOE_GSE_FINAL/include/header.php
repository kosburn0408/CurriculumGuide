<header id="header" class="header header-hide">
    <div class="container">
        <div id="logo" class="pull-left">
            <a href="#body"><img src="img/logo.jpg" alt="" title="" /></a>
        </div>
        <nav id="nav-menu-container">
            <ul class="nav-menu">
                <li class="menu-active"><a href="#hero">Home</a></li>
                <li><a href="#about-us">Links</a></li>
                <li><a href="#get-started">Introduction</a></li>
                <li><a href="#pricing">Grade Expanded</a></li>
            </ul>
        </nav>
    </div>
</header>